BTNMindtoMind
By PeeKay

Description:
Transfer some intelligence on allie hero or steal some mana or int from enemy. Icon for that sort of spells.


Please give me credit for my work
Do not redistribute this icon without consent!

Icon was uploaded 2011, June 27
Icon was last updated 2011, June 27


Visit http://www.hiveworkshop.com for more downloads